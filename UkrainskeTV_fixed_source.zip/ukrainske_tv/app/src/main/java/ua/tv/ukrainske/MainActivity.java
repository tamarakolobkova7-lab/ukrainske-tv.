package ua.tv.ukrainske;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.FrameLayout;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8,13,18), PANEL = Color.rgb(18,28,38), GOLD = Color.rgb(255,213,79), WHITE = Color.WHITE, MUTED = Color.rgb(174,190,202);
    private LinearLayout root, list;
    private FrameLayout content;
    private WebView web;
    private TextView status;
    private final List<Channel> channels = new ArrayList<>();
    private boolean favoritesOnly = false;
    private final java.util.Set<String> favorites = new java.util.HashSet<>();
    private static class Channel { String name, category, url; Channel(String n,String c,String u){name=n;category=c;url=u;} }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        seedChannels(); buildHome();
    }
    private void seedChannels() {
        // Links point to official broadcaster pages. A page is not guaranteed to expose a free live stream.
        channels.add(new Channel("Перший", "Суспільне", "https://tv.suspilne.media/live"));
        channels.add(new Channel("Суспільне Культура", "Суспільне", "https://suspilne.media/culture/"));
        channels.add(new Channel("1+1", "Розважальні", "https://1plus1.video/tvguide/1plus1/online"));
        channels.add(new Channel("1+1 Україна", "Розважальні", "https://1plus1.video/tvguide/1plus1ukr/online"));
        channels.add(new Channel("ICTV", "Розважальні та кіно", "https://ictv.ua/ua/online/"));
        channels.add(new Channel("ICTV2", "Розважальні та кіно", "https://ictv.ua/ua/broadcasting/"));
        channels.add(new Channel("СТБ", "Розважальні та кіно", "https://www.stb.ua/"));
        channels.add(new Channel("Новий канал", "Розважальні та кіно", "https://novy.tv/"));
        channels.add(new Channel("2+2", "Розважальні та кіно", "https://1plus1.video/tvguide/2plus2/online"));
        channels.add(new Channel("ТЕТ", "Розважальні та кіно", "https://tet.tv/"));
        channels.add(new Channel("Інтер", "Розважальні та кіно", "https://inter.ua/"));
        channels.add(new Channel("НТН", "Розважальні та кіно", "https://ntn.ua/"));
        channels.add(new Channel("К1", "Розважальні та кіно", "https://k1.ua/"));
        channels.add(new Channel("К2", "Розважальні та кіно", "https://k2.ua/"));
        channels.add(new Channel("М1", "Музичні", "https://m1.tv/"));
        channels.add(new Channel("ПЛЮСПЛЮС", "Дитячі", "https://plus-plus.tv/"));
        channels.add(new Channel("Бігуді", "Серіали", "https://bigudi.tv/"));
        channels.add(new Channel("Мега", "Пізнавальні", "https://mega.tv/"));
        channels.add(new Channel("Супер+", "Розважальні та кіно", "https://superplus.ua/"));
        channels.add(new Channel("Ми — Україна", "Новини", "https://weukraine.tv/"));
        channels.add(new Channel("Рада", "Новини", "https://www.rada.gov.ua/"));
        channels.add(new Channel("24 Канал", "Новини", "https://24tv.ua/online"));
        channels.add(new Channel("5 канал", "Новини", "https://www.5.ua/live"));
        channels.add(new Channel("Прямий", "Новини", "https://prm.ua/live/"));
        channels.add(new Channel("Еспресо", "Новини", "https://espreso.tv/online"));
        channels.add(new Channel("Армія TV", "Новини", "https://armyinform.com.ua/"));
        channels.add(new Channel("УНІАН", "Новини", "https://www.unian.ua/"));
        channels.add(new Channel("XSPORT", "Спорт", "https://xsport.ua/"));
        channels.add(new Channel("Піксель TV", "Дитячі", "https://pixeltv.ua/"));
        channels.add(new Channel("Сонце", "Розважальні та кіно", "https://sonce.tv/"));
        channels.add(new Channel("Zoom", "Розважальні та кіно", "https://zoomtv.com.ua/"));
        channels.add(new Channel("Ентер-фільм", "Розважальні та кіно", "https://enterfilm.com/"));
    }
    private GradientDrawable shape(int color, int stroke) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(12)); if(stroke!=0)d.setStroke(dp(2),stroke); return d; }
    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    private TextView text(String value, int size, int color, boolean bold) { TextView t=new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private void buildHome() {
        if (web != null) { web.stopLoading(); web.destroy(); web = null; }
        root = new LinearLayout(this); root.setOrientation(LinearLayout.HORIZONTAL); root.setBackgroundColor(BG); root.setPadding(dp(24),dp(20),dp(24),dp(20)); setContentView(root);
        LinearLayout sidebar = new LinearLayout(this); sidebar.setOrientation(LinearLayout.VERTICAL); sidebar.setPadding(0,0,dp(20),0); root.addView(sidebar,new LinearLayout.LayoutParams(dp(240),-1));
        TextView brand=text("🇺🇦  Українське ТБ",24,WHITE,true); brand.setPadding(0,dp(6),0,dp(8)); sidebar.addView(brand);
        TextView sub=text("Безкоштовні офіційні джерела",13,MUTED,false); sidebar.addView(sub);
        Button all=navButton("Усі канали"); all.setOnClickListener(v->{favoritesOnly=false;refreshList();}); sidebar.addView(all);
        Button fav=navButton("★  Обране"); fav.setOnClickListener(v->{favoritesOnly=true;refreshList();}); sidebar.addView(fav);
        Button help=navButton("Як це працює"); help.setOnClickListener(v->showHelp()); sidebar.addView(help);
        TextView foot=text("Оберіть канал пультом.\nЕфір доступний, якщо мовник\nнадає онлайн-перегляд.",13,MUTED,false); foot.setPadding(0,dp(20),0,0); sidebar.addView(foot);
        content=new FrameLayout(this); root.addView(content,new LinearLayout.LayoutParams(0,-1,1));
        LinearLayout panel=new LinearLayout(this); panel.setOrientation(LinearLayout.VERTICAL); content.addView(panel,new FrameLayout.LayoutParams(-1,-1));
        TextView heading=text("Українські телеканали",28,WHITE,true); heading.setPadding(0,0,0,dp(14)); panel.addView(heading);
        status=text("Оберіть канал і відкрийте безкоштовний IPTV-плейлист у VLC.",14,MUTED,false); panel.addView(status);
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(false); panel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(2),dp(12),dp(10),dp(16)); scroll.addView(list);
        refreshList();
    }
    private Button navButton(String label) { Button b=new Button(this); b.setText(label); b.setTextColor(WHITE); b.setTextSize(16); b.setAllCaps(false); b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL); b.setBackground(shape(PANEL,0)); b.setFocusable(true); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54)); p.topMargin=dp(10); b.setLayoutParams(p); return b; }
    private void refreshList() {
        if(list==null)return; list.removeAllViews();
        String last="";
        for(Channel c:channels) {
            if(favoritesOnly&&!favorites.contains(c.name))continue;
            if(!c.category.equals(last)){ TextView cat=text(c.category.toUpperCase(),13,GOLD,true); cat.setPadding(dp(6),dp(14),0,dp(6)); list.addView(cat); last=c.category; }
            LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(16),dp(4),dp(10),dp(4)); row.setBackground(shape(PANEL,0)); row.setFocusable(true); row.setFocusableInTouchMode(true);
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(62)); rp.bottomMargin=dp(8); list.addView(row,rp);
            TextView logo=text(shortName(c.name),20,GOLD,true); logo.setGravity(Gravity.CENTER); logo.setBackground(shape(Color.rgb(34,48,60),0)); row.addView(logo,new LinearLayout.LayoutParams(dp(68),dp(46)));
            TextView name=text(c.name,20,WHITE,true); name.setPadding(dp(16),0,0,0); row.addView(name,new LinearLayout.LayoutParams(0,-2,1));
            Button star=new Button(this); star.setText(favorites.contains(c.name)?"★":"☆"); star.setTextColor(GOLD); star.setTextSize(22); star.setAllCaps(false); star.setBackgroundColor(Color.TRANSPARENT); row.addView(star,new LinearLayout.LayoutParams(dp(58),dp(52))); star.setOnClickListener(v->{if(!favorites.add(c.name))favorites.remove(c.name);refreshList();});
            row.setOnClickListener(v->openChannel(c)); row.setOnFocusChangeListener((v,has)->row.setBackground(shape(has?Color.rgb(39,54,67):PANEL,has?GOLD:0)));
            row.setOnKeyListener((v,key,event)->{if(event.getAction()==KeyEvent.ACTION_UP&&(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER)){openChannel(c);return true;}return false;});
        }
        if(list.getChildCount()==0){TextView empty=text("Тут поки немає обраних каналів. Натисніть ☆ біля каналу.",18,MUTED,false); list.addView(empty);}
    }
    private String shortName(String n){ if(n.equals("Новий канал"))return "НОВИЙ"; if(n.equals("Суспільне"))return "СУСПІЛЬНЕ"; if(n.equals("Ми — Україна"))return "МИ UA"; return n.toUpperCase(); }
    private void openChannel(Channel c) {
        content.removeAllViews();
        LinearLayout page=new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL); page.setGravity(Gravity.CENTER); page.setPadding(dp(32),dp(24),dp(32),dp(24)); page.setBackgroundColor(BG); content.addView(page,new FrameLayout.LayoutParams(-1,-1));
        TextView title=text(c.name,30,WHITE,true); title.setGravity(Gravity.CENTER); page.addView(title);
        TextView info=text("Щоб дивитися безкоштовні канали, відкрийте IPTV-плейлист у VLC. Доступність окремих трансляцій залежить від джерела.",18,MUTED,false); info.setGravity(Gravity.CENTER); info.setPadding(0,dp(20),0,dp(24)); page.addView(info);
        Button play=new Button(this); play.setText("Відкрити українські канали у VLC"); play.setAllCaps(false); play.setTextSize(20); play.setFocusable(true); page.addView(play,new LinearLayout.LayoutParams(-1,dp(64)));
        play.setOnClickListener(v -> {
            String playlist="https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8";
            try {
                android.content.Intent intent=new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(playlist));
                intent.setPackage("org.videolan.vlc");
                startActivity(intent);
            } catch (Exception e) {
                try { startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(playlist))); }
                catch (Exception ignored) { status=text("Не вдалося відкрити плейлист. Перевірте підключення до Wi-Fi та VLC.",16,MUTED,false); page.addView(status); }
            }
        });
        Button back=new Button(this); back.setText("← Повернутися до каналів"); back.setAllCaps(false); back.setOnClickListener(v->buildHome()); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(56)); bp.topMargin=dp(14); page.addView(back,bp);
        play.requestFocus();
    }
    private void showHelp() {
        content.removeAllViews(); LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(28),dp(24),dp(28),dp(24)); content.addView(p);
        TextView h=text("Як користуватися",28,WHITE,true); p.addView(h);
        TextView body=text("1. Виберіть канал стрілками пульта та натисніть OK.\n\n2. Натисніть «Відкрити українські канали у VLC». VLC відкриє безкоштовний IPTV-плейлист; доступність окремих каналів залежить від джерела.\n\n3. Поверніться до програми кнопкою «← Канали».\n\nПотрібне підключення до інтернету. Платні трансляції не обходяться.",18,MUTED,false); body.setPadding(0,dp(18),0,dp(18)); p.addView(body);
        Button back=new Button(this); back.setText("Повернутися до каналів"); back.setAllCaps(false); back.setOnClickListener(v->buildHome()); p.addView(back);
    }
    @Override public void onBackPressed(){ buildHome(); }
}
