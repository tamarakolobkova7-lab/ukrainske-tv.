# Українське ТБ — вбудований повноекранний плеєр

Android TV app uses AndroidX Media3 ExoPlayer. Selecting a channel hides the channel list and opens video edge-to-edge fullscreen. Press Back on the remote to return to the list.

Build with Java 17 and Gradle 8.9 via GitHub Actions. Free third-party IPTV links may change or be unavailable.
