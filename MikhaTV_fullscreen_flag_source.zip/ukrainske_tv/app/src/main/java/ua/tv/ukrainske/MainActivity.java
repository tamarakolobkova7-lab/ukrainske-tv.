package ua.tv.ukrainske;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import android.content.pm.ActivityInfo;
import android.view.WindowManager;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,12,24), PANEL=Color.rgb(16,30,56), BLUE=Color.rgb(20,82,190), GOLD=Color.rgb(255,213,79), WHITE=Color.WHITE, MUTED=Color.rgb(185,200,220);
    private static final String PLAYLIST="https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8";
    private LinearLayout root, list;
    private FrameLayout right;
    private TextView status;
    private ProgressBar spinner;
    private PlayerView playerView;
    private ExoPlayer player;
    private final List<Channel> channels=new ArrayList<>();
    private final Handler main=new Handler(Looper.getMainLooper());
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private boolean loading=false, fullscreen=false;
    private static class Channel { String name, group, url; Channel(String n,String g,String u){name=n;group=g;url=u;} }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        enterImmersive();
        buildLayout();
        loadPlaylist();
    }
    private void enterImmersive(){
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable shape(int c,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(10));if(stroke!=0)d.setStroke(dp(2),stroke);return d;}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private void buildLayout(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.HORIZONTAL);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(14),dp(18),dp(14));setContentView(root);
        LinearLayout side=new LinearLayout(this);side.setOrientation(LinearLayout.VERTICAL);side.setPadding(0,0,dp(16),0);root.addView(side,new LinearLayout.LayoutParams(dp(300),-1));
        side.addView(txt("🇺🇦  Миха ТВ",25,WHITE,true));
        TextView subtitle=txt("Безкоштовні онлайн-трансляції",14,MUTED,false);subtitle.setPadding(0,dp(5),0,dp(10));side.addView(subtitle);
        status=txt("Завантажую список каналів…",14,GOLD,false);side.addView(status);
        spinner=new ProgressBar(this);side.addView(spinner,new LinearLayout.LayoutParams(dp(38),dp(38)));
        ScrollView sc=new ScrollView(this);side.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);
        right=new FrameLayout(this);right.setBackground(shape(PANEL,0));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-1,1);rp.leftMargin=dp(8);root.addView(right,rp);showWelcome();
    }
    private void showWelcome(){
        fullscreen=false;root.setVisibility(View.VISIBLE);right.removeAllViews();LinearLayout p=new LinearLayout(this);p.setGravity(Gravity.CENTER);p.setOrientation(LinearLayout.VERTICAL);right.addView(p,new FrameLayout.LayoutParams(-1,-1));
        TextView title=txt("Оберіть телеканал",30,WHITE,true);title.setGravity(Gravity.CENTER);p.addView(title);
        TextView msg=txt("Після вибору відео відкриється на весь екран телевізора.",20,MUTED,false);msg.setGravity(Gravity.CENTER);msg.setPadding(0,dp(16),0,0);p.addView(msg);
    }
    private void loadPlaylist(){
        if(loading)return;loading=true;status.setText("Завантажую IPTV-плейлист…");spinner.setVisibility(View.VISIBLE);
        io.execute(()->{
            List<Channel> parsed=new ArrayList<>();String error=null;
            try{
                HttpURLConnection c=(HttpURLConnection)new URL(PLAYLIST).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestProperty("User-Agent","UkrainskeTV/1.1");c.connect();
                if(c.getResponseCode()!=200)throw new Exception("HTTP "+c.getResponseCode());
                BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
                String line,name=null,group="";while((line=r.readLine())!=null){line=line.trim();if(line.startsWith("#EXTINF")){name=line.substring(line.lastIndexOf(',')+1).trim();group=attr(line,"group-title");if(name.isEmpty())name=attr(line,"tvg-name");}else if(!line.isEmpty()&&!line.startsWith("#")&&name!=null){String meta=(group+" "+line).toLowerCase(Locale.ROOT);boolean uk=meta.contains("ukraine")||meta.contains("ukrainian")||meta.contains("ukr")||meta.contains("country=\"ua\"");if(uk&&!name.toLowerCase(Locale.ROOT).contains("adult")&&parsed.size()<250)parsed.add(new Channel(name,group,line));name=null;}}
                r.close();c.disconnect();if(parsed.isEmpty())error="Не знайдено каналів України в цьому плейлисті.";
            }catch(Exception e){error="Не вдалося завантажити список: "+e.getMessage();}
            final String err=error;final List<Channel> got=parsed;main.post(()->{loading=false;spinner.setVisibility(View.GONE);channels.clear();channels.addAll(got);if(channels.isEmpty()){status.setText(err==null?"Немає каналів":err);list.removeAllViews();TextView help=txt("Перевірте Wi‑Fi та спробуйте знову.",16,MUTED,false);list.addView(help);Button retry=button("Повторити");retry.setOnClickListener(v->loadPlaylist());list.addView(retry);}else{status.setText("Каналів: "+channels.size());renderChannels();}});
        });
    }
    private String attr(String s,String key){String n=key+"=\"";int i=s.indexOf(n);if(i<0)return "";i+=n.length();int j=s.indexOf('"',i);return j<0?"":s.substring(i,j);}
    private Button button(String label){Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextColor(WHITE);b.setTextSize(16);b.setBackground(shape(BLUE,0));b.setFocusable(true);return b;}
    private void renderChannels(){list.removeAllViews();String last="";for(Channel ch:channels){if(!ch.group.equals(last)&&!ch.group.isEmpty()){TextView cat=txt(ch.group,13,GOLD,true);cat.setPadding(dp(4),dp(12),0,dp(4));list.addView(cat);last=ch.group;}Button b=button(ch.name);b.setGravity(Gravity.START|Gravity.CENTER_VERTICAL);b.setPadding(dp(12),0,dp(8),0);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.bottomMargin=dp(5);list.addView(b,lp);b.setOnClickListener(v->play(ch));b.setOnKeyListener((v,k,e)->{if(e.getAction()==KeyEvent.ACTION_UP&&(k==KeyEvent.KEYCODE_DPAD_CENTER||k==KeyEvent.KEYCODE_ENTER)){play(ch);return true;}return false;});}if(list.getChildCount()>0)list.getChildAt(0).requestFocus();}
    private void play(Channel ch){
        fullscreen=true;root.setVisibility(View.GONE);getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        FrameLayout full=new FrameLayout(this);full.setBackgroundColor(Color.BLACK);setContentView(full);
        playerView=new PlayerView(this);playerView.setUseController(true);playerView.setControllerAutoShow(true);playerView.setKeepScreenOn(true);playerView.setResizeMode(androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT);
        full.addView(playerView,new FrameLayout.LayoutParams(-1,-1));
        TextView channelName=txt(ch.name,18,WHITE,true);channelName.setBackgroundColor(0x99000000);channelName.setPadding(dp(14),dp(8),dp(14),dp(8));FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.START);full.addView(channelName,tp);
        releasePlayer();player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);player.addListener(new Player.Listener(){@Override public void onPlayerError(PlaybackException e){Toast.makeText(MainActivity.this,"Потік недоступний",Toast.LENGTH_LONG).show();}});player.setMediaItem(MediaItem.fromUri(ch.url));player.prepare();player.play();
        playerView.requestFocus();
    }
    private void releasePlayer(){if(player!=null){player.release();player=null;}playerView=null;}
    @Override public boolean onKeyDown(int keyCode,KeyEvent event){if(keyCode==KeyEvent.KEYCODE_BACK){if(fullscreen){releasePlayer();buildLayout();loadPlaylist();return true;}return super.onKeyDown(keyCode,event);}return super.onKeyDown(keyCode,event);}
    @Override protected void onStop(){super.onStop();if(player!=null)player.pause();}
    @Override protected void onDestroy(){releasePlayer();io.shutdownNow();super.onDestroy();}
}
